public class Tools {
    public static int powi(int base, int exp) {
        return (int) Math.pow(base, exp);
    }
}
